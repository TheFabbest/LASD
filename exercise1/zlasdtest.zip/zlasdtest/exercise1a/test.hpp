
#ifndef EX1ATEST_HPP
#define EX1ATEST_HPP

/* ************************************************************************** */

void testSimpleExercise1A(unsigned int &, unsigned int &);

void testFullExercise1A(unsigned int &, unsigned int &);

/* ************************************************************************** */

#endif
