
#include <iostream>

/* ************************************************************************** */

void testFullExercise3(uint &, uint &) {
}
